<?php 
class Rokanthemes_Categorytab_Block_Categorytab_Widget_Advanced
    extends Rokanthemes_Categorytab_Block_Categorytab_Advanced
    implements Mage_Widget_Block_Interface
{
    /**
     * Internal contructor
     *
     */
    protected function _construct()
    {
        
        parent::_construct();

    }
}
