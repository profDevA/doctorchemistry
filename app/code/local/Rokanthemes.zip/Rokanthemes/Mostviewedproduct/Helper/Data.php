<?php

class Rokanthemes_Mostviewedproduct_Helper_Data extends Mage_Core_Helper_Abstract
{

}