<?php

class Rokanthemes_Explodemenu_Helper_Data extends Mage_Core_Helper_Abstract
{

}